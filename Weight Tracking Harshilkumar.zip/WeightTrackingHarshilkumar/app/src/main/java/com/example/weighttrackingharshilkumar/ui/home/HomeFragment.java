package com.example.weighttrackingharshilkumar.ui.home;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import com.example.weighttrackingharshilkumar.DatabaseHelper;
import com.example.weighttrackingharshilkumar.R;
import com.example.weighttrackingharshilkumar.SessionManager;
import com.example.weighttrackingharshilkumar.WeightHistory;
import com.example.weighttrackingharshilkumar.WeightHistoryAdapter;
import com.example.weighttrackingharshilkumar.databinding.FragmentHomeBinding;
import java.util.List;

public class HomeFragment extends Fragment {

    private FragmentHomeBinding binding;
    private ListView listView;
    private List<WeightHistory> weightHistoryList;
    private WeightHistoryAdapter adapter;
    private DatabaseHelper dbHelper;
    private SessionManager sessionManager;
    private TextView textGoalWeight;

    private TextView textNoHistory;



    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        HomeViewModel homeViewModel = new ViewModelProvider(this).get(HomeViewModel.class);

        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        // Initialize database helper and session manager
        dbHelper = new DatabaseHelper(getContext());
        sessionManager = new SessionManager(getContext());

        // Initialize UI elements
        listView = binding.listViewWeightHistory;
        textGoalWeight = binding.textGoalWeight;
        textNoHistory = binding.textNoHistory;


        // Load data
        int userId = sessionManager.getUserId();
        initializeList(userId);
        loadGoalWeightFromDatabase(userId);

        // Set up buttons
        Button buttonAddWeight = root.findViewById(R.id.buttonAddWeight);
        Button buttonModifyGoal = root.findViewById(R.id.buttonModifyGoal);

        buttonAddWeight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NavController navController = Navigation.findNavController(getActivity(), R.id.nav_host_fragment_content_main);
                navController.navigate(R.id.action_nav_home_to_nav_add_weight);
            }
        });

        buttonModifyGoal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NavController navController = Navigation.findNavController(getActivity(), R.id.nav_host_fragment_content_main);
                navController.navigate(R.id.action_nav_home_to_nav_modify_goal);
            }
        });

        return root;
    }

    @Override
    public void onResume() {
        super.onResume();
        int userId = sessionManager.getUserId(); // Get user ID from session
        loadGoalWeightFromDatabase(userId); // Reload goal weight when the fragment resumes
        initializeList(userId); // Reload weight history when the fragment resumes

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    private void initializeList(int userId) {
        weightHistoryList = dbHelper.getWeightHistory(userId);
        if (weightHistoryList.isEmpty()) {
            textNoHistory.setVisibility(View.VISIBLE);
            listView.setVisibility(View.GONE);
        } else {
            textNoHistory.setVisibility(View.GONE);
            listView.setVisibility(View.VISIBLE);
            adapter = new WeightHistoryAdapter(getContext(), weightHistoryList);
            listView.setAdapter(adapter);
        }
    }

    private void loadGoalWeightFromDatabase(int userId) {
        String goalWeight = sessionManager.getGoalWeight();
        if (goalWeight != null) {
            textGoalWeight.setText(goalWeight + " lbs");
        } else {
            textGoalWeight.setText("No goal set");
        }
    }


}
