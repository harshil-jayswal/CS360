package com.example.weighttrackingharshilkumar.ui.addweight;

import androidx.lifecycle.ViewModel;

public class AddWeightViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
