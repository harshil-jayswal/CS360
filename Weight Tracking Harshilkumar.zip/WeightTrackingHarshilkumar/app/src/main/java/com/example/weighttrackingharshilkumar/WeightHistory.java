package com.example.weighttrackingharshilkumar;

public class WeightHistory {
    private String weight;
    private String date;
    private String time;

    public WeightHistory(String weight, String date, String time) {
        this.weight = weight;
        this.date = date;
        this.time = time;
    }

    public String getWeight() {
        return weight;
    }

    public String getDate() {
        return date;
    }

    public String getTime() {
        return time;
    }
}

