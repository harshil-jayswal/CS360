package com.example.weighttrackingharshilkumar;

import android.app.Activity;

public class SMSPermissionActivity extends Activity {
}
