package com.example.weighttrackingharshilkumar.ui.signin;

import androidx.lifecycle.ViewModel;

public class SigninViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}