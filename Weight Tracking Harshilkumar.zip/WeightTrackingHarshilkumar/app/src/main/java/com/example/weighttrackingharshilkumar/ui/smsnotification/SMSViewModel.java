package com.example.weighttrackingharshilkumar.ui.smsnotification;

import androidx.lifecycle.ViewModel;

public class SMSViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}