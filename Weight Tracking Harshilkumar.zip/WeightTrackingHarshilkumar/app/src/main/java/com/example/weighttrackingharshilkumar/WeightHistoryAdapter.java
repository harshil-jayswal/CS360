package com.example.weighttrackingharshilkumar;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

public class WeightHistoryAdapter extends BaseAdapter {
    private Context context;
    private List<WeightHistory> weightHistoryList;

    public WeightHistoryAdapter(Context context, List<WeightHistory> weightHistoryList) {
        this.context = context;
        this.weightHistoryList = weightHistoryList;
    }

    @Override
    public int getCount() {
        return weightHistoryList.size();
    }

    @Override
    public Object getItem(int position) {
        return weightHistoryList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.list_item_weight_history, parent, false);
        }

        TextView textWeight = convertView.findViewById(R.id.textWeight);
        TextView textDate = convertView.findViewById(R.id.textDate);
        TextView textTime = convertView.findViewById(R.id.textTime);

        WeightHistory weightHistory = weightHistoryList.get(position);

        textWeight.setText(weightHistory.getWeight());
        textDate.setText(weightHistory.getDate());
        textTime.setText(weightHistory.getTime());

        return convertView;
    }
}

